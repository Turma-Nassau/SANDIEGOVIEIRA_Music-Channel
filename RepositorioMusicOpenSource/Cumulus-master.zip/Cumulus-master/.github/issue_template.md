Note: playback issues are probably caused by the rate limiting issue first described in issue #89.

Please check if your issue could be caused by the rate limiting issue before reporting it and vote for the original issue using the thumbs-up emoji instead of creating a new issue so we can better track affected users. Sadly this issue is caused by Soundcloud themselves so there is nothing we can do about it at the moment.

-- Please remove this notice from your issue --
