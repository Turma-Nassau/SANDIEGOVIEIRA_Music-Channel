'use strict';

var McFly = require('mcfly');

var mcFly = new McFly();

module.exports = mcFly;