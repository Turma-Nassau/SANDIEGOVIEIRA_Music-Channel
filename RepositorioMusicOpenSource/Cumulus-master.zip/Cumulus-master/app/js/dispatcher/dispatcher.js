var mcfly = require('../utils/mcfly');

module.exports = mcfly.dispatcher;
